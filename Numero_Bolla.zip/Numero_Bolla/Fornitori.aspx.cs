using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;

public partial class Fornitori : System.Web.UI.Page
{

	protected void Page_Load(object sender, EventArgs e)
  {
		if (!IsPostBack)
		{
			//	----------------------------------------------------------------------------------------------------
			//	Carico i DropDownList per Societ� e Organization Unit
			//	----------------------------------------------------------------------------------------------------
			myParameters parSocieta = new myParameters();
			myParameter p;
			if ((string)Session["flSocieta"] == "1")
			{ p = new myParameter("@Societa", SqlDbType.Char, 2, ""); }
			else
			{ p = new myParameter("@Societa", SqlDbType.Char, 2, (string)Session["dsCodSoc"]); }
			parSocieta.Add((SqlParameter)p.CreateSQLParameter());
			//
			Helper.FillDropDownList(cboSocieta, DBHelper.GetSPDataSet("BOL_sp_EstraiSocieta", parSocieta), "ceSocieta", "deSocieta", null, null, null);
			//	----------------------------------------------------------------------------------------------------
			//	Se risulta una sola societ�, la si seleziona
			//	----------------------------------------------------------------------------------------------------
			if (cboSocieta.Items.Count == 2) cboSocieta.SelectedIndex = 1;

			//	----------------------------------------------------------------------------------------------------
			//	Se sono SuperAdmin posso gestire tutte le societ�, altrimenti solo quella dell'utente
			//	----------------------------------------------------------------------------------------------------
			if ((string)Session["flSocieta"] == "1")
			{
				Panel_Societa.Visible = true;
			}
			else
			{
				cboSocieta.SelectedValue = (string)Session["dsCodSoc"];
				lblSocieta.Text = cboSocieta.SelectedItem.ToString();
				Visua_Societa.Visible = true;
			}
		}
  }

	protected void Page_LoadComplete(object sender, EventArgs e)
	{
		//if (Panel_Errore.Visible == false)
		BindData();
		if (cboSocieta.SelectedIndex == 0 && (string)Session["flSuper"] == "1")
		{ cmd_Nuovo.Visible = true; }
		else
		{ cmd_Nuovo.Visible = false; }
	}


	//	----------------------------------------------------------------------------------------------------------------------------------------
	//	Carico dataset della tabella BOL_TB_FORNITORI da mostrare nella datagrid
	//	----------------------------------------------------------------------------------------------------------------------------------------
	private void BindData()
	{
		DataSet ds;
		ds = GetFornitori(cboSocieta.SelectedValue.ToString(), txtRicerca.Text.ToString());
		if (ds.Tables[0].Rows.Count > 0)
		{
			dgFornitori.DataSource = ds;
			dgFornitori.DataBind();
			dgFornitori.Visible = true;
			Panel_None.Visible = false;
			lbl_Numero.Text = ds.Tables[0].Rows.Count.ToString();
			Panel_Trovati.Visible = true;
		}
		else
		{
			Panel_None.Visible = true;
			dgFornitori.Visible = false;
			Panel_Trovati.Visible = false;
		}
		return;
	}

	public static DataSet GetFornitori(string societa, string ricerca)
	{
		myParameters collP = new myParameters();
		myParameter p;

		//	----------------------------------------------------------------------------------------------------------------------------------------
		//	Estrazione dei Fornitori in funzione del codice societ� selezionato
		//	----------------------------------------------------------------------------------------------------------------------------------------
		p = new myParameter("@IfSocieta", SqlDbType.Char, 2, (string)societa);
		collP.Add((SqlParameter)p.CreateSQLParameter());
		//
		if (!string.IsNullOrEmpty(societa))
		{
			p = new myParameter("@Societa", SqlDbType.Char, 2, (string)societa);
			collP.Add((SqlParameter)p.CreateSQLParameter());
		}
		if (!string.IsNullOrEmpty(ricerca) && ricerca.TrimEnd() != "")
		{
			p = new myParameter("@Ricerca", SqlDbType.VarChar, 50, (string)ricerca);
			collP.Add((SqlParameter)p.CreateSQLParameter());
		}
		DataSet ds;
		ds = DBHelper.GetSPDataSet("BOL_sp_EstraiFornitori", collP);
		return ds;
	}


	//	----------------------------------------------------------------------------------------------------------------------------------------
	//	Navigazione su elenco fornitori
	//	----------------------------------------------------------------------------------------------------------------------------------------
	public void dgFornitori_PageIndexChanged(object sender, DataGridPageChangedEventArgs e)
	{
		dgFornitori.SelectedIndex = -1;
		Panel_Fornitore.Visible = false;
		dgFornitori.CurrentPageIndex = e.NewPageIndex;
	}

	protected void btnCerca_Click(object sender, ImageClickEventArgs e)
	{
		dgFornitori.SelectedIndex = -1;
		dgFornitori.CurrentPageIndex = 0;
		Panel_Fornitore.Visible = false;
	}

	protected void cboVisua_SelectedIndexChanged(object sender, EventArgs e)
	{
		dgFornitori.PageSize = Convert.ToInt32(cboVisua.SelectedValue);
		dgFornitori.CurrentPageIndex = 0;
	}


	//	----------------------------------------------------------------------------------------------------
	//	Operazione inserimento nuovo fornitore
	//	----------------------------------------------------------------------------------------------------
	protected void cmd_Nuovo_OnClick(object sender, EventArgs e)
	{
		dgFornitori.SelectedIndex = -1;
		dgFornitori.Enabled = false;
		Panel_Fornitore.Visible = false;
		newFornitore.Text = "";
		newRagSociale.Text = "";
		Panel_Nuovo.Visible = true;
	}

	protected void cmd_Inserisci_OnClick(object sender, EventArgs e)
	{
		insErrore.Text = "";
		//
		if (newFornitore.Text == "") insErrore.Text = "<BR />Indicare la ragione sociale!";
		//
		if (insErrore.Text != "")
		{
			Panel_Errori.Visible = true;
		}
		else
		{
			Fornitore NewFornitore = new Fornitore();
			NewFornitore.Insert_Fornitore(newFornitore.Text, newRagSociale.Text);
			Panel_Errori.Visible = false;
			Panel_Nuovo.Visible = false;
			dgFornitori.SelectedIndex = -1;
			dgFornitori.Enabled = true;
		}
	}


	protected void cmd_Annulla_OnClick(object sender, EventArgs e)
	{
		Panel_Nuovo.Visible = false;
		dgFornitori.Enabled = true;
	}


	//	----------------------------------------------------------------------------------------------------------------------------------------
	//	Visualizzazione dettaglio fornitore
	//	----------------------------------------------------------------------------------------------------------------------------------------
	protected void dgFornitori_Visualizza(object source, DataGridCommandEventArgs e)
	{
		switch (e.CommandName)
		{
			case "Expand":
				dgFornitori.SelectedIndex = e.Item.ItemIndex;
				Panel_Fornitore.Visible = true;
				break;

			case "Collapse":
				dgFornitori.SelectedIndex = -1;
				Panel_Fornitore.Visible = false;
				break;
		}
	}

	protected void dgFornitori_Dettaglio(object source, DataGridItemEventArgs e)
	{
		if (e.Item.DataItem != null)
		{
			ListItemType itemType = e.Item.ItemType;
			System.Web.UI.Control container = e.Item;

			if (itemType == ListItemType.SelectedItem)
			{
				//	----------------------------------------------------------------------------------------------------
				//	Cambio l'immagine dell'imagebutton
				//	----------------------------------------------------------------------------------------------------
				ImageButton btnExp = (ImageButton)container.FindControl("BtnExpand");
				btnExp.ImageUrl = "~/Images/cmd_comprimi.gif";
				btnExp.CommandName = "Collapse";
				btnExp.ToolTip = "Nascondi dettagli fornitore";

				//	----------------------------------------------------------------------------------------------------
				//	Ricerca dettagli fornitore selezionato
				//	----------------------------------------------------------------------------------------------------
				Fornitore VisFornitore = new Fornitore((dgFornitori.DataKeys[e.Item.ItemIndex]).ToString());
				ViewState["Fornitore"] = VisFornitore;
				Session["Fornitore"] = VisFornitore.ceFornitore;
				ceFornitore.Text = VisFornitore.ceFornitore;
				deFornitore.Text = VisFornitore.deFornitore;
				deRagSociale.Text = VisFornitore.deRagSociale;
				nmEsterni.Text = VisFornitore.nmEsterni;

				//	----------------------------------------------------------------------------------------------------
				//	Ricerca societ� abilitate per fornitore selezionato
				//	----------------------------------------------------------------------------------------------------
				DataSet ds;
				ds = GetFornitoriSoc(VisFornitore.ceFornitore.ToString());
				dgSocAbil.DataSource = ds;
				dgSocAbil.DataBind();
				txtErroreDx.Visible = false;
			}
		}
	}

	protected static DataSet GetFornitoriSoc(string fornitore)
	{
		myParameter p;
		myParameters parFornSoc = new myParameters();
		p = new myParameter("@Fornitore", SqlDbType.Char, 2, fornitore);
		parFornSoc.Add((SqlParameter)p.CreateSQLParameter());
		//	----------------------------------------------------------------------------------------------------
		//	Estrazione delle Societ� collegate al Fornitore (@Socie = 'SI')
		//	----------------------------------------------------------------------------------------------------
		p = new myParameter("@Socie", SqlDbType.Char, 2, "SI");
		parFornSoc.Add((SqlParameter)p.CreateSQLParameter());
		//	----------------------------------------------------------------------------------------------------
		//
		DataSet ds;
		ds = DBHelper.GetSPDataSet("BOL_sp_EstraiFornitoreSoc", parFornSoc);
		return ds;
	}

	public DataSet CaricaSocieta()
	{
		//string strConnessione = System.Configuration.ConfigurationManager.AppSettings["connString"];
     //   SqlConnection strConnessione = new SqlConnection(CurrentEnvironment.CurrentEnvironment.DbConnectionString);
        SqlConnection myConnection = new SqlConnection(CurrentEnvironment.CurrentEnvironment.DbConnectionString);
		DataSet dsSocieta = new DataSet();
		//	----------------------------------------------------------------------------------------------------
		//	Estrazione delle Societ� collegate al Fornitore (@Socie = 'NO')
		//	----------------------------------------------------------------------------------------------------
		string strSQLDDL = "EXECUTE BOL_sp_EstraiFornitoreSoc " + Session["Fornitore"] + ", 'NO'";
		//	----------------------------------------------------------------------------------------------------
		SqlDataAdapter myDataAdapter = new SqlDataAdapter(strSQLDDL, myConnection);
		myDataAdapter.Fill(dsSocieta, "deSocieta");
		return dsSocieta;
	}

	protected void insSocieta_SelectedIndexChanged(object sender, EventArgs e)
	{
	}

	public void dgSocAbil_ItemCommand(Object sender, DataGridCommandEventArgs e)
	{
		string str_Societa;
		switch (e.CommandName)
		{

			//	----------------------------------------------------------------------------------------------------
			//	Inserimento abilitazione nuova societ�
			//	----------------------------------------------------------------------------------------------------

			case "Insert":
				str_Societa = ((DropDownList)(e.Item.FindControl("insSocieta"))).SelectedItem.Value.ToString();
				if (str_Societa.Trim() == "")
				{
					txtErroreDx.Text = "Selezionare la societ� da abilitare.";
					txtErroreDx.Visible = true;
				}
				else
				{
					FornitoreSoc NewFornSoc = new FornitoreSoc((string)Session["Fornitore"], str_Societa);
					NewFornSoc.Inserisci_Forn_Soc();
					dgSocAbil.EditItemIndex = -1;
					txtErroreDx.Visible = false;
				}
				break;

			//	----------------------------------------------------------------------------------------------------
			//	Inserimento abilitazione nuova societ�
			//	----------------------------------------------------------------------------------------------------

			case "Delete":
				str_Societa = dgSocAbil.DataKeys[e.Item.ItemIndex].ToString();
				FornitoreSoc DelFornSoc = new FornitoreSoc((string)Session["Fornitore"], str_Societa);
				DelFornSoc.Delete_Forn_Soc();
				dgSocAbil.EditItemIndex = -1;
				txtErroreDx.Visible = false;
				break;

			//	Altre operazioni
			default:
				break;
		}
	}


	//	----------------------------------------------------------------------------------------------------
	//	Cambia selezione Societ�
	//	----------------------------------------------------------------------------------------------------
	protected void cboSocieta_SelectedIndexChanged(object sender, EventArgs e)
	{
		dgFornitori.CurrentPageIndex = 0;
		dgFornitori.SelectedIndex = -1;
		Panel_Fornitore.Visible = false;
	}

}
