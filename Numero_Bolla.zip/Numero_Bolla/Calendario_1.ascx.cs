using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Globalization;

public partial class Calendario_1 : System.Web.UI.UserControl
{

	protected void Page_Load(object sender, EventArgs e)
	{
		//	----------------------------------------------------------------------------------------------------
		//	Se non � PostBack inizializzo la data con quella attuale
		//	----------------------------------------------------------------------------------------------------
		if (!IsPostBack)
		{
			set_Data_1_Sel(DateTime.Now);
		}
	}


	//	----------------------------------------------------------------------------------------------------
	//	Visualizzazione della data selezionata e memorizzazione su parametri di sessione
	//	----------------------------------------------------------------------------------------------------
	private void set_Data_1_Sel(DateTime data_Sel)
	{
		txt_Data_1.Text = data_Sel.ToShortDateString();
		txt_Data_1.Style["text-align"] = "center";
		Session["Data_Da"] = data_Sel.ToShortDateString();
		Session["DataDa"] = data_Sel.Date;
	}


	//	----------------------------------------------------------------------------------------------------
	//	Selezione nuova data
	//	----------------------------------------------------------------------------------------------------
	protected void Calendario_1_SelectionChanged(object sender, EventArgs e)
	{
		set_Data_1_Sel(calCalendario_1.SelectedDate);
	}

	protected void Calendario_1_MonthChanged(object sender, MonthChangedEventArgs e)
	{
		string scriptString = "<script language='JavaScript' id='Div&ImgVisible'>";
		scriptString=scriptString +  "document.getElementById('Div_Calendario_1').style.visibility = 'visible';";
		scriptString = scriptString + "</script>";
		if (!Page.ClientScript.IsStartupScriptRegistered("Div&ImgVisible"))
			Page.ClientScript.RegisterStartupScript(typeof(Page), "Div&ImgVisible", scriptString);
	}

}
