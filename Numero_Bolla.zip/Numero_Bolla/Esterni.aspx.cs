using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;

public partial class Esterni : System.Web.UI.Page
{
  protected void Page_Load(object sender, EventArgs e)
  {

		if (!IsPostBack)
		{
			//	----------------------------------------------------------------------------------------------------
			//	Carico il DropDownList per tutti Fornitori presenti sul DB: forzato '**' in @IfSocieta
			//	----------------------------------------------------------------------------------------------------
			myParameters parForn = new myParameters();
			myParameter p;
			//
			p = new myParameter("@IfSocieta", SqlDbType.Char, 2, "**");
			parForn.Add((SqlParameter)p.CreateSQLParameter());
			Helper.FillDropDownList(cboFornitore, DBHelper.GetSPDataSet("BOL_sp_EstraiFornitori", parForn), "ceFornitore", "deFornitore", null, null, null);
			//cboFornitore.SelectedIndex = 0;
			if (cboFornitore.SelectedIndex == 0 && cboFornitore.Items.Count == 2) cboFornitore.SelectedIndex = 1;
		}
	}

	protected void Page_LoadComplete(object sender, EventArgs e)
	{
		Panel_Trovati.Visible = false;
		Panel_None.Visible = false;
		//
		if (cboFornitore.SelectedIndex == 0)
		{
			Panel_Inizio.Visible = true;
			dgEsterni.Visible = false;
		}
		else
		{
			Panel_Inizio.Visible = false;
			BindData();
		}
	}


	//	----------------------------------------------------------------------------------------------------------------------------------------
	//	Carico dataset della tabella BOL_TB_ESTERNI da mostrare nella datagrid
	//	----------------------------------------------------------------------------------------------------------------------------------------
	private void BindData()
	{
		DataSet ds;
		ds = GetEsterni(cboFornitore.SelectedValue.ToString(), txtRicerca.Text.ToString());
		if (ds.Tables[0].Rows.Count > 0)
		{
			dgEsterni.DataSource = ds;
			dgEsterni.DataBind();
			dgEsterni.Visible = true;
			lbl_Numero.Text = ds.Tables[0].Rows.Count.ToString();
			Panel_Trovati.Visible = true;
		}
		else
		{
			Panel_None.Visible = true;
			dgEsterni.Visible = false;
		}
		return;
	}

	public static DataSet GetEsterni(string fornitore, string ricerca)
	{
		myParameters collP = new myParameters();
		myParameter p;
		if (!string.IsNullOrEmpty(fornitore))
		{
			p = new myParameter("@Fornitore", SqlDbType.NChar, 8, (string)fornitore);
			collP.Add((SqlParameter)p.CreateSQLParameter());
		}
		if (!string.IsNullOrEmpty(ricerca) && ricerca.TrimEnd() != "")
		{
			p = new myParameter("@Ricerca", SqlDbType.VarChar, 50, (string)ricerca);
			collP.Add((SqlParameter)p.CreateSQLParameter());
		}
		DataSet ds;
		ds = DBHelper.GetSPDataSet("BOL_sp_EstraiEsterni", collP);
		return ds;
	}

	protected string SetCheckBox(Boolean valCampo)
	{
		if (valCampo)
			return "<img src='" + ResolveUrl("~/Images/check_on.gif") + "' alt='' />";
		else
			return "<img src='" + ResolveUrl("~/Images/check_off.gif") + "' alt='' />";
	}



	//	----------------------------------------------------------------------------------------------------------------------------------------
	//	Navigazione su elenco operatori esterni
	//	----------------------------------------------------------------------------------------------------------------------------------------

	public void dgEsterni_PageIndexChanged(object sender, DataGridPageChangedEventArgs e)
	{
		dgEsterni.SelectedIndex = -1;
		Panel_Esterno.Visible = false;
		dgEsterni.CurrentPageIndex = e.NewPageIndex;
	}

	protected void btnCerca_Click(object sender, ImageClickEventArgs e)
	{
		dgEsterni.SelectedIndex = -1;
		dgEsterni.CurrentPageIndex = 0;
		Panel_Esterno.Visible = false;
	}

	protected void cboVisua_SelectedIndexChanged(object sender, EventArgs e)
	{
		dgEsterni.PageSize = Convert.ToInt32(cboVisua.SelectedValue);
		dgEsterni.CurrentPageIndex = 0;
	}


	//	----------------------------------------------------------------------------------------------------
	//	Operazione inserimento nuovo utente esterno
	//	----------------------------------------------------------------------------------------------------
	protected void cmd_Nuovo_OnClick(object sender, EventArgs e)
	{
	}


	//	----------------------------------------------------------------------------------------------------------------------------------------
	//	Visualizzazione dettaglio utente esterno
	//	----------------------------------------------------------------------------------------------------------------------------------------
	protected void dgEsterni_Visualizza(object source, DataGridCommandEventArgs e)
	{
		switch (e.CommandName)
		{
			case "Expand":
				dgEsterni.SelectedIndex = e.Item.ItemIndex;
				Panel_Esterno.Visible = true;
				break;

			case "Collapse":
				dgEsterni.SelectedIndex = -1;
				Panel_Esterno.Visible = false;
				break;
		}
	}

	protected void dgEsterni_Dettaglio(object source, DataGridItemEventArgs e)
	{
		if (e.Item.DataItem != null)
		{
			ListItemType itemType = e.Item.ItemType;
			System.Web.UI.Control container = e.Item;

			if (itemType == ListItemType.SelectedItem)
			{
				//	----------------------------------------------------------------------------------------------------
				//	Cambio l'immagine dell'imagebutton
				//	----------------------------------------------------------------------------------------------------
				ImageButton btnExp = (ImageButton)container.FindControl("BtnExpand");
				btnExp.ImageUrl = "~/Images/cmd_comprimi.gif";
				btnExp.CommandName = "Collapse";
				btnExp.ToolTip = "Nascondi dettagli";

				//	----------------------------------------------------------------------------------------------------
				//	Ricerca dettagli utente selezionato
				//	----------------------------------------------------------------------------------------------------
				Esterno VisEsterno = new Esterno((dgEsterni.DataKeys[e.Item.ItemIndex]).ToString());
				ViewState["Esterno"] = VisEsterno;
				utEsterno.Text = VisEsterno.deCognome + " " + VisEsterno.deNome;
				utLogin.Text = VisEsterno.ceLogin;
				utFornitore.Text = VisEsterno.deFornitore;
				utEmail.Text = VisEsterno.deEmail;
				utAbilitato.Text = Normal_Data(VisEsterno.dtAbilitato);
				utPwdValid.Text = Normal_Data(VisEsterno.dtPwdValid);
				utBolla.Text = Normal_Data(VisEsterno.dtBolla);
				utBolleSt.Text = VisEsterno.nmBolleSt;
				utBolleAC.Text = VisEsterno.nmBolleAC;
				utDisabilitato.Text = Normal_Data(VisEsterno.dtDisabil);
				ckbAbilitato.Checked = VisEsterno.flAbilitato;
			}
		}
	}

	protected string Normal_Data(DateTime data)
	{
		if (data.ToShortDateString() == "01/01/1900")
			return "--";
		else
			return data.ToShortDateString();
	}


	//	----------------------------------------------------------------------------------------------------
	//	Operazione su utente selezionato
	//	----------------------------------------------------------------------------------------------------
	protected void cmdModifica_OnClick(object sender, EventArgs e)
	{
		Esterno updEsterno;
		updEsterno = (Esterno)ViewState["Esterno"];
		if (updEsterno.flAbilitato != ckbAbilitato.Checked)
		{
			updEsterno.flAbilitato = ckbAbilitato.Checked;
			if (ckbAbilitato.Checked)
			{
				updEsterno.dtAbilitato = DateTime.Now;
				updEsterno.dtDisabil = Convert.ToDateTime("01/01/1900");
				updEsterno.dtPwdValid = DateTime.Now.AddYears(1);
			}
			else
			{
				updEsterno.dtDisabil = DateTime.Now;
			}
			updEsterno.Abilita_Esterno();

			//	----------------------------------------------------------------------------------------------------
			//	Invio Email abilitazione/diabilitazione utente esterno
			//	----------------------------------------------------------------------------------------------------
			MandaMail mail = new MandaMail((string)Session["dsMainEmail"], updEsterno.deEmail, "Gestione bolle manuali", Body_Mail((Esterno)ViewState["Esterno"]));
			mail.SendMail_Bolla();
		}

		dgEsterni.SelectedIndex = -1;
		Panel_Esterno.Visible = false;
	}

	//	----------------------------------------------------------------------------------------------------
	//	Preparazione testo della Email
	//	----------------------------------------------------------------------------------------------------
	private string Body_Mail(Esterno mail)
	{
		System.Text.StringBuilder strBodyMail = new System.Text.StringBuilder();

		strBodyMail.Append("<table cellpadding='5' cellspacing='5'>");
		////
		strBodyMail.Append("<tr width='900px'>");
		strBodyMail.Append("<td colspan='2' align='center' style='background-color: #6699DD; font-family: Tahoma; font-size: x-small; font-weight: bold'>");
		strBodyMail.Append("Modifica operativit� per l'utente&nbsp;&nbsp;&nbsp;" + mail.deCognome + " " + mail.deNome + "</td>");
		strBodyMail.Append("</tr>");
		strBodyMail.Append("<tr>");
		strBodyMail.Append("<td colspan='2' style='font-family: Tahoma; font-size: X-small'>");
		strBodyMail.Append("Si comunica che l'utente:</td></tr>");
		//
		strBodyMail.Append("<tr valign='top'>");
		strBodyMail.Append("<td width='100px' style='font-family: Tahoma; font-size: X-small'>");
		strBodyMail.Append("Cognome:");
		strBodyMail.Append("</td>");
		strBodyMail.Append("<td width='700px' style='font-family: Tahoma; font-size: X-small; font-weight: bold'>");
		strBodyMail.Append(mail.deCognome + "<br /></td>");
		strBodyMail.Append("</tr>");
		//
		strBodyMail.Append("<tr valign='top'>");
		strBodyMail.Append("<td width='100px' style='font-family: Tahoma; font-size: X-small'>");
		strBodyMail.Append("Nome:");
		strBodyMail.Append("</td>");
		strBodyMail.Append("<td width='700px' style='font-family: Tahoma; font-size: X-small; font-weight: bold'>");
		strBodyMail.Append(mail.deNome + "<br /></td>");
		strBodyMail.Append("</tr>");
		//
		strBodyMail.Append("<tr valign='top'>");
		strBodyMail.Append("<td width='200px' style='font-family: Tahoma; font-size: X-small'>");
		strBodyMail.Append("Societ�:<br />");
		strBodyMail.Append("</td>");
		strBodyMail.Append("<td width='700px' style='font-family: Tahoma; font-size: X-small; font-weight: bold'>");
		strBodyMail.Append(mail.deFornitore + "<br />");
		strBodyMail.Append("</td>");
		strBodyMail.Append("</tr>");
		//
		if (mail.flAbilitato)
		{
			strBodyMail.Append("<tr valign='top'>");
			strBodyMail.Append("<td colspan='2' style='font-family: Tahoma; font-size: X-small'>");
			strBodyMail.Append("� stato abilitato all'utilizzo dell'applicazione per l'emissione delle Bolle Manuali!<br />");
			strBodyMail.Append("<br /><br />");
			strBodyMail.Append("L'indirizzo per il collegamento all'applicazione � '");
			strBodyMail.Append("<A href='http://www.siemens.it/numero_bolla_ext'><font color='Navy'>http://www.siemens.it/numero_bolla_ext</font></A>'.");
			strBodyMail.Append("<br /><br />");
			strBodyMail.Append("Al momento del collegamento dovr� digitare:");
			strBodyMail.Append("</td>");
			strBodyMail.Append("</tr>");
			//
			strBodyMail.Append("<tr valign='top'>");
			strBodyMail.Append("<td width='200px' style='font-family: Tahoma; font-size: X-small'>");
			strBodyMail.Append("Login:");
			strBodyMail.Append("</td>");
			strBodyMail.Append("<td width='700px' style='font-family: Tahoma; font-size: X-small; font-weight: bold'>");
			strBodyMail.Append(mail.ceLogin + "<br /></td>");
			strBodyMail.Append("</tr>");
			//
			strBodyMail.Append("<tr valign='top'>");
			strBodyMail.Append("<td width='200px' style='font-family: Tahoma; font-size: X-small'>");
			strBodyMail.Append("Password:");
			strBodyMail.Append("</td>");
			strBodyMail.Append("<td width='700px' style='font-family: Tahoma; font-size: X-small; font-weight: bold'>");
			strBodyMail.Append(mail.dePassword + "<br /></td>");
			strBodyMail.Append("</tr>");
		}
		else
		{
			strBodyMail.Append("<tr><td colspan='2'>&nbsp;</td></tr>");
			strBodyMail.Append("<tr valign='top'>");
			strBodyMail.Append("<td colspan='2' style='font-family: Tahoma; font-size: X-small'>");
			strBodyMail.Append("� stato disabilitato dall'utilizzo dell'applicazione per l'emissione delle Bolle Manuali!");
			strBodyMail.Append("</td>");
			strBodyMail.Append("</tr>");
		}
		//
		strBodyMail.Append("<tr><td colspan='2'>&nbsp;</td></tr>");
		//
		strBodyMail.Append("</table>");
		//
		strBodyMail.Append("<table>");
		strBodyMail.Append("<tr style='background-color: #6699DD; height: 1px'><td width='900px' style='height: 1px'></td></tr>");
		strBodyMail.Append("</table>");
		//
		return strBodyMail.ToString();
	}


	//	----------------------------------------------------------------------------------------------------
	//	Cambia selezione Fornitore
	//	----------------------------------------------------------------------------------------------------
	protected void cboFornitore_SelectedIndexChanged(object sender, EventArgs e)
	{
		dgEsterni.CurrentPageIndex = 0;
		dgEsterni.SelectedIndex = -1;
		Panel_Esterno.Visible = false;
	}

}
