using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class BolleRicerca : System.Web.UI.Page
{
  protected void Page_Load(object sender, EventArgs e)
  {
		if (!IsPostBack)
		{
			Panel_Inizio.Visible = true;
		}
  }

	//protected void Page_LoadComplete(object sender, EventArgs e)
	//{
	//  if (Panel_Inizio.Visible == false)
	//    //BindData();
	//    //if (txtCercaBol.Text != "")
	//    {
	//    //  Panel_Inizio.Visible = false;
	//      //BindData();
	//    }
	//}

	//	----------------------------------------------------------------------------------------------------
	//	Ricerca per numero bolla
	//	----------------------------------------------------------------------------------------------------
	protected void btnCercaBol_Click(object sender, ImageClickEventArgs e)
	{
		Panel_Inizio.Visible = true;
		Panel_Bolla.Visible = false;
		Panel_None.Visible = false;
		//
		if (txtCercaBol.Text != "")
		{
			Panel_Inizio.Visible = false;
			Visualizza_Bolla(txtCercaBol.Text, "B");
			if (dettProgr.Text == "")
			{ Panel_None.Visible = true; }
			else
			{ Panel_Bolla.Visible = true; }
		}
	}


	//	----------------------------------------------------------------------------------------------------------------------------------------
	//	Visualizza dettagli elemento selezionato
	//	----------------------------------------------------------------------------------------------------------------------------------------
	public void Visualizza_Bolla(string bolla, string tipo)
	{
		dettProgr.Text = "";
		Bolla VisBolla = new Bolla();
		VisBolla.GetBolla(bolla, "B");
		//	----------------------------------------------------------------------------------------------------------------------------------------
		//	Se non trovo la bolla nell'anno in corso si esegue la ricerca sullo storico
		//	----------------------------------------------------------------------------------------------------------------------------------------
		if (VisBolla.ceProgr == "") VisBolla.GetBolla(bolla, "S");
		//
		if (VisBolla.ceProgr != "")
		{
			dettAnno.Text = VisBolla.ceAnno;
			dettProgr.Text = VisBolla.ceProgr;
			dettSocieta.Text = VisBolla.deSocieta;
			dettOrgUnit.Text = VisBolla.deOrgUnit;
			dettCDC.Text = VisBolla.deCDC;
			//
			dettUtGid.Text = VisBolla.ceUtente;
			dettUtNome.Text = VisBolla.deNome;
			if (!VisBolla.flUtente)
			{
				dettUtFornitore.Text = VisBolla.deFornitore;
				Panel_Fornitore.Visible = true;
				Panel_UtSocieta.Visible = false;
			}
			else
			{
				dettUtSocieta.Text = VisBolla.utSocieta;
				dettUtSede.Text = VisBolla.utSede;
				dettUtOrgUnit.Text = VisBolla.utOrgUnit;
				Panel_Fornitore.Visible = false;
				Panel_UtSocieta.Visible = true;
			}
			dettMotivo.Text = VisBolla.deMotivo;
			dettRiferimento.Text = VisBolla.deRiferimento;
			dettSpedizione.Text = VisBolla.ceSpedizione;
			dettDestinazione.Text = "";
			if (!string.IsNullOrEmpty(VisBolla.ceDestinazione))
			{ dettDestinazione.Text = VisBolla.ceDestinazione + "<br />"; }
			dettDestinazione.Text = dettDestinazione.Text + VisBolla.deDestinazione;
		}
	}

}
