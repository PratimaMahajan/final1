using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using Microsoft.Reporting.WebForms;

public partial class Report_OrgUnit : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!IsPostBack)
		{
			Rv_OrgUnit.ShowReportBody = false;
			Panel_Select.Visible = true;
			//	----------------------------------------------------------------------------------------------------
			//	Carico il DropDownList per Societ�
			//	----------------------------------------------------------------------------------------------------
			myParameter p;
			myParameters parSocieta = new myParameters();
			if ((string)Session["flSocieta"] == "1")
			{ p = new myParameter("@Societa", SqlDbType.Char, 2, ""); }
			else
			{ p = new myParameter("@Societa", SqlDbType.Char, 2, (string)Session["dsCodSoc"]); }
			parSocieta.Add((SqlParameter)p.CreateSQLParameter());
			//
			Helper.FillDropDownList(cboSocieta, DBHelper.GetSPDataSet("BOL_sp_EstraiSocieta", parSocieta), "ceSocieta", "deSocieta", null, null, null);
			//	----------------------------------------------------------------------------------------------------
			//	Se risulta una sola societ�, la si seleziona
			//	----------------------------------------------------------------------------------------------------
			if (cboSocieta.Items.Count == 2)
			{ cboSocieta.SelectedIndex = 1; }
			else
			{ cboSocieta.SelectedIndex = 0; }
		}

  }


	//	----------------------------------------------------------------------------------------------------
	//	Cambia selezione Societ�
	//	----------------------------------------------------------------------------------------------------
	protected void cboSocieta_SelectedIndexChanged(object sender, EventArgs e)
	{
		Panel_Select.Visible = true;
		Panel_Nuovo.Visible = false;
		Rv_OrgUnit.ShowReportBody = false;
	}


	//	----------------------------------------------------------------------------------------------------
	//	Creazione report bolle per OrganizationUnit
	//	----------------------------------------------------------------------------------------------------
	protected void Report_OrgUnit_Click(object sender, EventArgs e)
	{
		//Rv_OrgUnit.ShowReportBody = false;
		Err_Societa.Visible = false;
		Err_Date.Visible = false;
		if (cboSocieta.SelectedIndex == 0 && cboSocieta.SelectedValue.ToString() == "")
		{
			Err_Societa.Visible = true;
			return;
		}
		if ((DateTime)Session["DataDa"] > (DateTime)Session["DataA"])
		{
			Err_Date.Visible = true;
			return;
		}

		Session.Add("Societa", cboSocieta.SelectedValue.ToString());
		Session.Add("DataDa", (DateTime)Session["DataDa"]);
		Session.Add("DataA", (DateTime)Session["DataA"]);
		SetReportParameters();
		Rv_OrgUnit.ShowReportBody = true;
		Panel_Select.Visible = false;
		Panel_Nuovo.Visible = true;
	}

	private void SetReportParameters()
	{
		string s_data_da = (string)Session["Data_Da"];
		DateTime d_data_da = Convert.ToDateTime((string)Session["Data_Da"]);
		ReportParameter Societa = new ReportParameter("Societa", cboSocieta.SelectedItem.ToString());
		this.Rv_OrgUnit.LocalReport.SetParameters(new ReportParameter[] { Societa });
		ReportParameter Data_Da = new ReportParameter("Data_Da", (string)Session["Data_Da"]);
		this.Rv_OrgUnit.LocalReport.SetParameters(new ReportParameter[] { Data_Da });
		ReportParameter Data_A = new ReportParameter("Data_A", (string)Session["Data_A"]);
		this.Rv_OrgUnit.LocalReport.SetParameters(new ReportParameter[] { Data_A });
		//this.Rv_OrgUnit.ShowReportBody = true;
	}


	protected void New_Report_Click(object sender, EventArgs e)
	{
		Panel_Select.Visible = true;
		Panel_Nuovo.Visible = false;
		Rv_OrgUnit.ShowReportBody = false;
	}
}
