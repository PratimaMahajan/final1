using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for Esterno
/// </summary>


[Serializable()]
public class Esterno
{
	private string _ceLogin;
	private string _deCognome;
	private string _deNome;
	private string _dePassword;
	private string _deEmail;
	private string _ceFornitore;
	private string _deFornitore;
	private bool _flAbilitato;
	private DateTime _dtAbilitato;
	private DateTime _dtBolla;
	private DateTime _dtDisabil;
	private DateTime _dtPwdValid;
	private string _nmBolleAC;
	private string _nmBolleSt;

	public string ceLogin
	{
		get { return _ceLogin; }
		set { _ceLogin = value; }
	}

	public string deCognome
	{
		get { return _deCognome; }
	}

	public string deNome
	{
		get { return _deNome; }
	}

	public string dePassword
	{
		get { return _dePassword; }
	}

	public string deEmail
	{
		get { return _deEmail; }
	}

	public string ceFornitore
	{
		get { return _ceFornitore; }
	}

	public string deFornitore
	{
		get { return _deFornitore; }
	}

	public bool flAbilitato
	{
		set { _flAbilitato = value; }
		get { return _flAbilitato; }
	}

	public DateTime dtBolla
	{
		set { _dtBolla = value; }
		get { return _dtBolla; }
	}

	public DateTime dtAbilitato
	{
		set { _dtAbilitato = value; }
		get { return _dtAbilitato; }
	}

	public DateTime dtDisabil
	{
		set { _dtDisabil = value; }
		get { return _dtDisabil; }
	}

	public DateTime dtPwdValid
	{
		set { _dtPwdValid = value; }
		get { return _dtPwdValid; }
	}

	public string nmBolleAC
	{
		get { return _nmBolleAC; }
	}

	public string nmBolleSt
	{
		get { return _nmBolleSt; }
	}


	//	----------------------------------------------------------------------------------------------------
	//	Estrazione dati utente
	//	----------------------------------------------------------------------------------------------------
	public Esterno(string login)
	{
		myParameters collP = new myParameters();
		myParameter p;
		//
		p = new myParameter("@Login", SqlDbType.VarChar, 15, login);
		collP.Add(p.CreateSQLParameter());
		SqlDataReader dr = DBHelper.GetSPReader("BOL_sp_GetEsterno", collP);
		//
		if ((dr != null) && dr.Read())
		{
			_ceLogin = dr["ceLogin"].ToString();
			_deCognome = dr["deCognome"].ToString();
			_deNome = dr["deNome"].ToString();
			_dePassword = dr["dePassword"].ToString();
			_deEmail = dr["deEmail"].ToString();
			_ceFornitore = dr["ceFornitore"].ToString();
			_deFornitore = dr["deFornitore"].ToString();
			_flAbilitato = Convert.ToBoolean(dr["flAbilitato"].ToString());
			_dtAbilitato = Convert.ToDateTime(dr["dtAbilitato"].ToString());
			_dtBolla = Convert.ToDateTime(dr["dtBolla"].ToString());
			_dtDisabil = Convert.ToDateTime(dr["dtDisabil"].ToString());
			_dtPwdValid = Convert.ToDateTime(dr["dtPwdValidity"].ToString());
			_nmBolleAC = dr["nmBolleAC"].ToString();
			_nmBolleSt = dr["nmBolleSt"].ToString();
		}
		else
		{
			_ceLogin = "";
		}
		dr.Close();
	}


	//	----------------------------------------------------------------------------------------------------
	//	Modifica utente esterno
	//	----------------------------------------------------------------------------------------------------
	public void Abilita_Esterno()
	{
		myParameters collP = new myParameters();
		myParameter p;
		//
		p = new myParameter("@Login", SqlDbType.VarChar, 16, _ceLogin);
		collP.Add(p.CreateSQLParameter());
		p = new myParameter("@FlAbilitato", SqlDbType.Bit, 1, _flAbilitato);
		collP.Add(p.CreateSQLParameter());
		p = new myParameter("@DtAbilitato", SqlDbType.DateTime, 8, _dtAbilitato);
		collP.Add(p.CreateSQLParameter());
		p = new myParameter("@DtPwdValid", SqlDbType.DateTime, 8, _dtPwdValid);
		collP.Add(p.CreateSQLParameter());
		if (!_flAbilitato)
		{ 
			p = new myParameter("@DtDisabilitato", SqlDbType.DateTime, 8, _dtDisabil);
				collP.Add(p.CreateSQLParameter());
		}
		SqlDataReader dr = DBHelper.GetSPReader("BOL_sp_UpdateEsternoAbil", collP);
	}

}
