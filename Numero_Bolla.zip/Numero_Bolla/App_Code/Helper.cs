using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for Helper
/// </summary>
public class Helper
{
	public Helper()
	{
		//
		// TODO: Add constructor logic here
		//
	}

	public static void FillDropDownList(System.Web.UI.WebControls.DropDownList objDropDownList, Object container, String value, String text, String valueDefault, String textDefault, String selectedValue)
	{
		objDropDownList.Items.Clear();
		objDropDownList.DataTextField = text;
		objDropDownList.DataValueField = value;
		objDropDownList.DataSource = container;

		objDropDownList.DataBind();

		if ((valueDefault != null) && (textDefault != null))
			objDropDownList.Items.Insert(0, new ListItem(textDefault, valueDefault));

		if (selectedValue != null)
			objDropDownList.SelectedIndex = objDropDownList.Items.IndexOf(objDropDownList.Items.FindByValue(selectedValue));
	}

	public static void ControlsReadOnly(System.Web.UI.ControlCollection ctrl)
	{

		foreach (System.Web.UI.Control obj in ctrl)
		{
			if (obj.GetType().Name == "TextBox")
				((TextBox)obj).ReadOnly = true;
			if (obj.GetType().Name == "DropDownList")
				((DropDownList)obj).Enabled = false;
			if (obj.GetType().Name == "ImageButton")
				((ImageButton)obj).Visible = false;
			ControlsReadOnly(obj.Controls);
		}
	}
}
