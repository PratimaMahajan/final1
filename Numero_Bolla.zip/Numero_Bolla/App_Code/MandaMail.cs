using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Net.Mail;

/// <summary>
/// Summary description for MandaMail
/// </summary>
/// 

public class MandaMail
{
	private String _from = System.Configuration.ConfigurationManager.AppSettings["From"];
	private String _to;
	private String[] _arrTo;
	private String _subject;
	private String _body;

	public String xTo
	{
		set { _to = value; }
	}

	public String Subject
	{
		set { _subject = value; }
	}

	public String Body
	{
		set { _body = value; }
	}

	public MandaMail(string par_strFrom, string par_strTo, string par_strSubject, string par_strBody)
	{
		_from = par_strFrom;
		_to = par_strTo;
		_arrTo = _to.Split(Convert.ToChar(";"));
		_subject = par_strSubject;
		_body = par_strBody;
	}

	public Boolean SendMail_Bolla()
	{
		MailMessage objMailMess = new MailMessage();
		MailAddress objMailFrom = new MailAddress(_from);
		MailAddress objMailTo;

		SmtpClient objSendMail = new SmtpClient();

		try
		{
			objMailMess.From = objMailFrom;

			for (int i = 0; i < _arrTo.Length; i++)
			{
				objMailTo = new MailAddress(_arrTo[i]);
				objMailMess.To.Add(objMailTo);
			}

			objMailMess.Subject = _subject;
			objMailMess.IsBodyHtml = true;
			objMailMess.Body = _body;

			objSendMail.Host = System.Configuration.ConfigurationManager.AppSettings["ServerMail"];
			objSendMail.DeliveryMethod = SmtpDeliveryMethod.Network;
			try
			{
				objSendMail.Send(objMailMess);
			}
			catch (SmtpException e)
			{
				throw e;
				return false;
			}
			return true;
		}
		catch (Exception ex)
		{
			throw ex;
			return false;
		}

	}
}
